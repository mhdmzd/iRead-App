package com.example.sms2telegram

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.regex.Pattern

class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Telephony.Sms.Intents.SMS_RECEIVED_ACTION) {
            val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
            for (sms in messages) {
                val messageBody = sms.messageBody
                val sender = sms.originatingAddress

                Log.d("SMS_RECEIVER", "SMS: $messageBody")

                val amount = extractAmount(messageBody)
                val refId = extractRefId(messageBody)

                if (amount != null && refId != null) {
                    val sharedPref = context.getSharedPreferences("BotPrefs", Context.MODE_PRIVATE)
                    val botToken = sharedPref.getString("bot_token", "") ?: ""
                    val chatId = sharedPref.getString("chat_id", "") ?: ""

                    if (botToken.isNotEmpty() && chatId.isNotEmpty()) {
                        val reportMessage = "✅ رسید واریز جدید تایید شد:\n\n💵 مبلغ: $amount\n🔍 کد پیگیری: $refId"
                        
                        // اجرای ارسال در پس‌زمینه با یک ترد جداگانه
                        Thread {
                            sendToTelegram(botToken, chatId, reportMessage)
                        }.start()
                    }
                }
            }
        }
    }

    private fun extractAmount(text: String): String? {
        val pattern = Pattern.compile("(?:مبلغ:?|واریز:?)\\s*([\\d,]+)")
        val matcher = pattern.matcher(text)
        return if (matcher.find()) matcher.group(1) else "نامشخص"
    }

    private fun extractRefId(text: String): String? {
        val pattern = Pattern.compile("\\b\\d{6,12}\\b")
        val matcher = pattern.matcher(text)
        return if (matcher.find()) matcher.group(0) else null
    }

    private fun sendToTelegram(botToken: String, chatId: String, message: String) {
        try {
            val urlString = "https://api.telegram.org/bot$botToken/sendMessage"
            val url = URL(urlString)
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")

            val postData = "chat_id=" + URLEncoder.encode(chatId, "UTF-8") +
                    "&text=" + URLEncoder.encode(message, "UTF-8")

            OutputStreamWriter(conn.outputStream).use { writer ->
                writer.write(postData)
                writer.flush()
            }

            val responseCode = conn.responseCode
            Log.d("SMS_RECEIVER", "Telegram Response: $responseCode")
            conn.disconnect()
        } catch (e: Exception) {
            Log.e("SMS_RECEIVER", "Error", e)
        }
    }
}
